setwd("C:\\Users\\IT24100036\\Desktop\\IT24100036_PS_Lab_04")  
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
str(branch_data)

boxplot(branch_data$Sales_X1, main="Boxplot of sales", ylab="Sales")

summary(branch_data$Advertising_X2)
quantile(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3-Q1
  
  lower_bound <- Q1 - 1.5* IQR
  upper_bound <- Q3 + 1.5*IQR
  
  outliers <- x[x<lower_bound | x> upper_bound]
  return(outliers)
}

find_outliers(branch_data$Years_X3)